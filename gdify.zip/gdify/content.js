!function(){
    let replacements = {
        'processing': 'blast processing',
        'orb buffer': 'orb buffer',
        'buffer': 'orb buffer',
        'gd': 'geometry dash',
        'geometry dash': 'geometry dash',
        'swag route': 'swag route',
        'route': 'swag route',
        'orb': 'warning warning danger orb',
        'danger': 'danger orb',
        'swag': 'swag orb',
        'choke point': 'choke point',
        'choke': 'choke point',
        'point': 'choke point',
        'dash': 'geometry dash',
        'geometry': 'geometry dash',
        'warning': 'warning warning danger orb',
        'danger': 'danger orb',
        'blast processing': 'blast processing',
        'blast': 'blast processing',
        'ship': 'ship',
        'ball': 'ball',
        'swingcopter': 'swingcopter',
        'swing':'swingcopter',
        'helicopter':'swingcopter',
        'spin copter':'spincopter',
        'spin':'spincopter',
        'copter':'spincopter',
        'spincopter':'spincopter',
        'swingcopter':'swingcopter',
        'triple spike': 'triple spike /\\/\\/\\',
        'double spike': 'double spike /\\/\\',
        'spike': 'triple spike /\\/\\/\\',
        'triple': 'triple spike /\\/\\/\\',
        'double': 'double spike /\\/\\',
        'block': 'block',
        'animation trigger': 'animation trigger',
        'animation': 'animation trigger',
        'trigger': 'animation trigger',
        'im dead': 'im dead',
        'dead': 'im dead',
        'stereo madness': 'stereo madness',
        'stereo': 'stereo madness',
        'madness': 'stereo madness',
        'mad': 'stereo madness',
        'back on track': 'back on track',
        'on track': 'back on track',
        'back': 'back on track',
        'track': 'back on track',
        'stream': 'want the stream?',
        'poltargeist': 'polargeist',
        'polar': 'polargeist',
        'grind demon': 'grind demon',
        'demon': 'grind demon',
        'grind': 'grind demon',
        'club': 'clubstep',
        'clubstep': 'clubstep',
        'step': 'clubstep',
        'dry out': 'dry out',
        'dry': 'dry out',
        'out': 'dry out',
        'can\'t': 'cant let go',
        'cant': 'cant let go',
        'let go': 'cant let go',
        'go': 'go go go go!',
        'gg':'ggez',
        'ez':'ggez',
        'ggez':'ggez',
        'base': 'base after base',
        ':':'GD COLON',
        'ericvanwilderman': 'ericvanwilderman',
        'evw':'ericvanwilderman',
        'colon': 'GD COLON',
        'eric': 'ericvanwilderman',
        'wilderman': 'ericvanwilderman',
        'van': 'ericVANwilderman',
        'ring': 'jump ring',
        'jump': 'jump ring',
        'world': 'GD world',
        'melt': 'GD meltdown',
        'meltdown': 'GD meltdown',
        'subzero': 'GD subzero',
        'zero': 'GD subzero',
        'sub': '1 mil subs on my YT bro',
        'subscribe': '1 mil subs on my YT bro',
        'recent': 'to the recent tab!',
        'tab': 'to the recent tab!',
        'rub': 'rubrub',
        'top': 'the cnot top',
        'rob': 'robtop',
        'robtop': 'Robert Topala',
        'egg': 'evw',
        'time': 'time machine',
        'machine': 'time machine',
        'robert': 'Robert Topala',
        'cnot': 'The cnot top',
        'lite': 'GD lite',
        'full': 'full version',
        'vault': 'vault of secrets',
        'jumper': 'jumper',
        'cycle': 'cycles',
        'cycles': 'cycles',
        'xstep': 'xstep',
        'clutter':'clutterfunk',
        'funk':'clutterfunk',
        'clutterfunk':'clutterfunk',
        'theory': 'theory of everything',
        'toe': 'theory of everything',
        'everything': 'theory of everything',
        'electro': 'electroman adventures',
        'adventures': 'electroman adventures',
        'electroman': 'electroman adventures',
        'adventure': 'electroman adventures',
        'dynamics': 'electrodynamix',
        'dynamix': 'electrodynamix',
        'dynamic': 'electrodynamix',
        'hexagon': 'hexagon force',
        'hex': 'hexagon force',
        'force': 'hexagon force',
        'toe2': 'theory of everything 2',
        'geometrical': 'geometrical dominator',
        'dominator': 'geometrical dominator',
        'lock': 'deadlocked',
        'locked': 'deadlocked',
        'challenge': 'the challenge',
        'finger': 'fingerdash',
        'fingerdash': 'chom baguettes',
        'explorers': 'explorers',
        'explore': 'explorers',
        'brad': 'brad GD',
        'william': 'williamlechatgd',
        'chat': 'williamlechatgd',
        'hack': 'megahack',
        'mega': 'megahack',
        'play': 'gameplay',
        'game': 'gameplay',
        'coin': 'coin route',
        'cube': 'cube gamemode',
        'easy': 'easy 2*',
        'hard': 'hard 4-5*',
        'normal': 'normal 3*',
        'harder': 'harder 6-7*',
        'auto': 'auto 1*',
        'bpi': 'BPI',
        'bli': 'BLI',
        'bii': 'BII',
        'insane': 'insane 8-9*',
        'medium': 'medium demon',
        'extreme': 'extreme demon',
        'wave': 'wave gamemode',
        'gamemode': 'GD gamemode',
        'mode': 'GD gamemode',
        'portal': 'GD portal',
        'portals': 'GD portals',
        'spam': 'wave spam',
        'scratch': 'cheuk scratch edition',
        'classic': 'classic mode',
        'platformer': 'platformer mode',
        'impossible': 'IMPOSSIBLE!',
        'clip': 'no clip',
        'no': 'no clip',
        'random': 'random ship mix',
        'mix': 'random ship mix',
        'slow': 'random ship mix slow',
        'warp': 'time warp',
        'lore': 'GD lore',
        'element': 'element 111 RG',
        'rg': 'element 111 RG',
        '111': 'element 111 RG',
        'dark': 'darkx',
        'danke': 'danke',
        'ta': 'danke',
        'level': 'GD level',
        'levels': 'GD levels',
        'treasure': 'treasure room',
        'key': 'demon key',
        'event': 'event level',
        'events': 'event levels',
        'weekly': 'weekly demon',
        'featured': 'featured levels',
        'daily': 'daily level',
        'quests': 'quests',
        'quest': 'quests',
        'chest': 'treasure chest',
        'chests': 'treasure chests',
        'shop': 'shop',
        'mechanic': 'mechanic',
        'icon': 'GD icon',
        'icons': 'GD icons',
        'player': 'GD player',
        'diamond': 'GD diamond',
        'diamonds': 'GD diamonds',
        'moldy': 'GD moldy',
        'mouldy': 'GD moldy',
        'bird': 'UFO',
        'birds': 'UFOs',
        '-': 'dash',
        '–': 'dash',
        '—': 'dash',
        '–': 'dash',
        '2': '2.2',
        'chamber': 'chamber of time',
        'user': 'user coins',
        'rate': 'rated',
        'rated': 'rated',
        'epic': 'epic rated',
        'legendary': 'legendary rated',
        'mythic': 'mythic rated',
        'legend': 'legendary rated',
        'myth': 'mythic rated',
        'mythical': 'mythic rated',
        'achievements': 'GD achievements',
        'achievement': 'GD achievement',
        'gauntlets': 'GD gauntlets',
        'gauntlet': 'GD gauntlet',
        'fire': 'fire gauntlet',
        'ice': 'ice carbon diablo x',
        'poison': 'poison gauntlet',
        'shadow': 'shadow gauntlet',
        'crystal': 'crystal gauntlet',
        'chaos': 'chaos gauntlet',
        'chaotic': 'chaos gauntlet',
        'ncs': 'ncs gauntlet',
        'space': 'space gauntlet',
        'cosmos': 'cosmos gauntlet',
        'lava': 'lava gauntlet',
        'bonus': 'bonus gauntlet',
        'magic': 'magic gauntlet',
        'doom': 'doom gauntlet',
        'monster': 'clubstep monster',
        'death': 'death gauntlet',
        'forest': 'forest gauntlet',
        'force': 'force gauntlet',
        'spooky': 'spooky gauntlet',
        'water': 'water gauntlet',
        'haunted': 'haunted gauntlet',
        'power': 'power gauntlet',
        'halloween': 'halloween gauntlet',
        'gem': 'gem gauntlet',
        'inferno': 'inferno gauntlet',
        'portal': 'portal gauntlet',
        'strange': 'strange gauntlet',
        'fantasy': 'fantasy gauntlet',
        'christmas': 'christmas gauntlet',
        'mystery': 'mystery gauntlet',
        'cursed': 'cursed thorn',
        'cyborg': 'cyborg gauntlet',
        'castle': 'castle gauntlet',
        'galaxy': 'galaxy gauntlet',
        'universe': 'galaxy gauntlet',
        'discord': 'discord gauntlet',
        'split': 'split gauntlet',
        'splits': 'split gauntlets',
        'circles': 'nine circles',
        'circle': 'nine circles',
        'blood': 'bloodbath',
        'bath': 'bloodbath',
        'b': 'B',
        'mission': 'Mission S',
        'cat': 'cataclysm',
        'amethyst': 'amethyst',
        'tray': 'retray',
        'sonar': 'sonar',
        'slam': 'slam',
        'nightmare': 'the nightmare',
        'lighting': 'the lightning road',
        'road': 'the lightning road',
        'outer': 'outer space',
        'spy': 'i spy with my little eye',
        'eye': 'i spy with my little eye',
        'promise': 'promises',
        'promises': 'promises',
        'acid': 'acid factory',
        'factory': 'acid factory',
        'platinum': 'platinum adventure',
        'adventure': 'platinum adventure',
        'xo': 'XO',
        'thinking': 'thinking space II',
        'tidal': 'tidal wave',
        'zodiac': 'zodiac',
        'problematic': 'problematic',
        'problem': 'problematic',
        'skeleton': 'skeletal shenanigans',
        'shenanigans': 'skeletal shenanigans',
        'shenanigan': 'skeletal shenanigans',
        'skeletal': 'skeletal shenanigans',
        'rattle': 'rattledash',
        'moon': 'death moon',
        'map': 'map pack',
        'pack': 'map pack',
        'coaster': 'coaster mountain',
        'mountain': 'coaster mountain',
        'tower': 'the tower',
        'rush': 'bossrush 2',
        'robot': 'GD robot',
        'spider': 'GD spider',
        'pink': 'pink orb',
        'yellow': 'yellow orb',
        'green': 'green orb',
        'blue': 'blue orb',
        'black': 'black orb',
        'red': 'red orb',
        'toggle': 'toggle orb',
        'trigger': 'trigger',
        'nerf': 'nerf',
        'buff': 'buff',
        'frame': 'frame perfect',
        'perfect': 'frame perfect',
        'geode': 'geode',
        'click': 'click between frames',
        'frames': 'click between frames',
        'cbf': 'click between frames',
        'globe': 'globed',
        'link': 'death link',
        'seven': 'the seven seas',
        'seas': 'the seven seas',
        'viking': 'viking arena',
        'arena': 'viking arena',
        'airborne': 'airborne robots',
        'robots': 'airborne robots',
        'press': 'press start',
        'start': 'press start',
        'nock': 'nock em',
        'em': 'nock em',
        'trip': 'power trip',
        'pay': 'payload',
        'load': 'payload',
        'beast': 'beast mode',
        'machina': 'machina',
        'year': 'years',
        'years': 'years',
        'front': 'frontlines',
        'lines': 'frontlines',
        'line': 'frontlines',
        'pirate': 'teminite',
        'pirates': 'teminite',
        'rum': 'teminite',
        'strike': 'striker',
        'striker': 'striker',
        'embers': 'embers',
        'ember': 'embers',
        'round': 'round 1',
        'dance': 'monster dance off'
    };

    let wordRegex = new RegExp('(' + Object.keys(replacements).join('|') + ')', 'gi');

    function isInSkippedElement(node) {
        let el = node.parentElement;
        let SKIP = new Set(['SCRIPT','STYLE','NOSCRIPT','IFRAME','IMG','TEXTAREA','SELECT','OPTION','INPUT']);
        while (el) {
            if (SKIP.has(el.tagName)) return true;
            if (el.tagName === 'GDTEXT') return true;
            el = el.parentElement;
        }
        return false;
    }

    function replaceTextNode(textNode) {
        let text = textNode.nodeValue;
        let match;
        let lastIndex = 0;
        let frag = document.createDocumentFragment();
        wordRegex.lastIndex = 0;
        while ((match = wordRegex.exec(text)) !== null) {
            let before = text.slice(lastIndex, match.index);
            if (before) frag.appendChild(document.createTextNode(before));
            let matchedKey = match[1].toLowerCase();
            let el = document.createElement('gdtext');
            el.setAttribute('gdrep', replacements[matchedKey]);
            el.setAttribute('gdkey', matchedKey);
            frag.appendChild(el);
            lastIndex = wordRegex.lastIndex;
        }
        if (lastIndex === 0) return; 
        let after = text.slice(lastIndex);
        if (after) frag.appendChild(document.createTextNode(after));
        textNode.parentNode.replaceChild(frag, textNode);
    }

    let walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT, {
        acceptNode(node) {
            if (!node.nodeValue || !node.nodeValue.trim()) return NodeFilter.FILTER_REJECT;
            if (isInSkippedElement(node)) return NodeFilter.FILTER_REJECT;
            return NodeFilter.FILTER_ACCEPT;
        }
    }, false);

    let textNodes = [];
    let n;
    while ((n = walker.nextNode())) textNodes.push(n);
    textNodes.forEach(replaceTextNode);
    let style = document.createElement('style');
    style.innerHTML = `@property --deg {
        syntax: '<angle>';
        inherits: false;
        initial-value: 90deg;
    }
    @keyframes spin{
        from{
            --deg: 0deg;
        }
        to{
            --deg: 360deg;
        }
    }
    @keyframes bounce{
        0%{
            transform:scale(1);
        }
        30%{
            transform:scale(1.2);
        }
        60%{
            transform:scale(0.9);
        }
        85%{
            transform:scale(1.1);
        }
        100%{
            transform:scale(1);
        }
    }
    gdtext {
        background:linear-gradient(var(--deg),#ff00ff,#00ff00) !important; 
        -webkit-background-clip:text !important;
        background-clip:text !important;
        color:transparent !important;
        font-weight:900 !important;
        display:inline-block !important;
        animation: bounce 0.5s ease-in-out !important;
        position: relative;
        /*animation: spin 4s linear infinite;*/
    }
    gdtext::before{
        content:attr(gdrep) !important;
        background:linear-gradient(var(--deg),#ff00ff,#00ff00) !important; 
        -webkit-background-clip:text !important;
        background-clip:text !important;
        color:transparent !important;
        font-weight:900 !important;
        display:inline-block !important;
        transition:150ms transform linear 150ms , 0s transition linear 150ms;
    }
    gdtext::after{
        content:attr(gdkey) !important;
        text-align:center !important;
        display:inline-block !important;
        position:absolute !important;
        width:100% !important;
        left:0 !important;
        color:red !important;
        font-weight:900 !important;
        transform:scaleY(0) !important;
        transition:150ms transform linear 0ms , 0s transition linear 150ms;
    }
    gdtext:hover::before {
        transform: scaleY(0);
        transition: 150ms transform linear 0ms, 0s transition linear 150ms;
    } 
    gdtext:hover::after {
        transform: scaleY(1) !important;
        transition: 150ms transform linear 150ms , 0s transition linear 150ms;
    }`;

    document.head.appendChild(style);
}();